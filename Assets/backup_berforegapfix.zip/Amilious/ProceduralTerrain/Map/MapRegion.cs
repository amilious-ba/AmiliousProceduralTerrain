namespace Amilious.ProceduralTerrain.Map {
    public class MapRegion {
        
    }
}