using System;
using System.Linq;
using Amilious.ProceduralTerrain.Mesh;
using Amilious.ProceduralTerrain.Noise;
using Amilious.ProceduralTerrain.Textures;
using Amilious.Threading;
using UnityEngine;

namespace Amilious.ProceduralTerrain.Map {
    public class MapChunk {

        private MeshSettings _meshSettings;
        private NoiseSettings _heightMapSettings;
        private Transform _viewer;
        private int _seed;
        private NoiseMap _heightMap;
        private bool _heightMapReceived;
        private bool _hasSetCollider;

        private GameObject meshObject;
        private Vector2 sampleCenter;
        private Vector2 
            position;
        private Bounds bounds;

        private MeshRenderer _meshRenderer;
        private MeshFilter _meshFilter;
        private MeshCollider _meshCollider;
        private LODInfo[] _detailLevels;
        private LODMesh[] _lodMeshes;
        private int _previousLODIndex = -1;

        public event Action<MapChunk, bool> onVisibilityChanged;
        
        public Vector2 Coordinate { get; private set; }
        public EndlessMap Map { get; private set; }
        
        
        public MapChunk(EndlessMap endlessMap, Vector2 chunkCoord) {
            Map = endlessMap;
            Coordinate = chunkCoord;
            _meshSettings = Map.MeshSettings;
            _heightMapSettings = Map.NoiseSettings;
            _viewer = Map.Viewer;
            _seed = Map.HashedSeed;
            _detailLevels = _meshSettings.LevelsOfDetail.ToArray();

            //TODO: look at this closely.  Why is the bounds not sample center?
            sampleCenter = Coordinate * _meshSettings.MeshWorldSize / _meshSettings.MeshScale;
            position = Coordinate * _meshSettings.MeshWorldSize;
            bounds = new Bounds(position, Vector3.one * _meshSettings.MeshWorldSize);
            
            //generate game object
            meshObject = new GameObject($"Chunk ({Coordinate.x},{Coordinate.y})") {
                transform = { position = new Vector3(position.x, 0, position.y),
                    parent = Map.transform }
            };
            _meshRenderer = meshObject.AddComponent<MeshRenderer>();
            _meshFilter = meshObject.AddComponent<MeshFilter>();
            _meshCollider = meshObject.AddComponent<MeshCollider>();
            _meshRenderer.material = _meshSettings.Material;
            SetVisible(false);
            
            //setup lod meshes
            _lodMeshes = new LODMesh[_detailLevels.Length];
            for(var i = 0; i < _detailLevels.Length; i++) {
                _lodMeshes[i] = new LODMesh(_detailLevels[i].LOD);
                _lodMeshes[i].UpdateCallback += UpdateMapChunk;
                if(i == _meshSettings.ColliderLODIndex)
                    _lodMeshes[i].UpdateCallback += UpdateCollisionMesh;
            }
        }

        private void SetVisible(bool visible) => meshObject.SetActive(visible);
        public bool IsVisible { get { return meshObject.activeSelf; } }
        
        private Vector2 ViewerPosition => new Vector2 (_viewer.position.x, _viewer.position.z);

        public void UpdateCollisionMesh() {
            if(_hasSetCollider) return;
            var sqrDistanceFromViewer = bounds.SqrDistance(ViewerPosition);
            if(sqrDistanceFromViewer < _detailLevels[_meshSettings.ColliderLODIndex].SqrVisibleDistanceThreshold)
                if(!_lodMeshes[_meshSettings.ColliderLODIndex].HasRequestedMesh)
                    _lodMeshes[_meshSettings.ColliderLODIndex].RequestMesh(_heightMap, Map.MaxHeight, _meshSettings);
            if(sqrDistanceFromViewer > Map.SqrColliderGenerationThreshold) return;
            if(!_lodMeshes[_meshSettings.ColliderLODIndex].HasMesh) return;
            _meshCollider.sharedMesh = _lodMeshes[_meshSettings.ColliderLODIndex].Mesh;
            _hasSetCollider = true;
        }


        public void UpdateMapChunk() {
            if(!_heightMapReceived) return;
            var distanceFromViewer = Mathf.Sqrt(bounds.SqrDistance(ViewerPosition));
            var wasVisible = IsVisible;
            var visible = distanceFromViewer <= _meshSettings.MaxViewDistance;
            if(visible) UpdateLOD(distanceFromViewer);
            if(wasVisible == visible) return;
            SetVisible(visible);
            onVisibilityChanged?.Invoke(this,visible);
        }

        private void UpdateLOD(float distanceFromViewer) {
            var lodIndex = 0;
            for(var i = 0; i < _detailLevels.Length - 1; i++) {
                if(distanceFromViewer > _detailLevels[i].VisibleDistanceThreshold)
                    lodIndex = i + 1;
                else break;
            }
            if(lodIndex == _previousLODIndex) return;
            var lodMesh = _lodMeshes[lodIndex];
            if(lodMesh.HasMesh) {
                _previousLODIndex = lodIndex;
                _meshFilter.mesh = lodMesh.Mesh;
                _meshRenderer.material.mainTexture = _heightMap.GenerateTexture(_heightMapSettings.PreviewColors, borderCulling:1);
            }else if(!lodMesh.HasRequestedMesh) {
                lodMesh.RequestMesh(_heightMap, Map.MaxHeight, _meshSettings);
            }
        }

        public void Load() {
            var future = new Future<NoiseMap>();
            future.OnSuccess((heightMap) => {
                _heightMap = heightMap.value;
                _heightMapReceived = true;
                UpdateMapChunk();
            });
            future.Process(()=> {
                var heightMap = _heightMapSettings.Generate((int)_meshSettings.VertsPerLine,_seed, sampleCenter);
                //modify the height map here without applying the height
                return heightMap;
            });
        }


    }
}