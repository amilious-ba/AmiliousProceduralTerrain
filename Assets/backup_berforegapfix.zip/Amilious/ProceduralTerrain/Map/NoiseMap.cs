using System;
using System.Collections.Generic;
using UnityEngine;

namespace Amilious.ProceduralTerrain.Map {
    
    /// <summary>
    /// This class is used to hold a noise map.
    /// </summary>
    public class NoiseMap{
        
        #region Properties
        
        /// <summary>
        /// This property contains the size of the noise map.
        /// </summary>
        public int Size { get; }
        
        /// <summary>
        /// This property contains the half size of the NoiseMap
        /// </summary>
        public float HalfSize { get; }
        
        /// <summary>
        /// This property contains the number of values stored in this NoiseMap.
        /// </summary>
        public int NumberOfValues { get; }

        /// <summary>
        /// This property contains the central position of the noise map.
        /// </summary>
        public Vector2 Position { get; }
    
        /// <summary>
        /// This property is used to get or set the value at the given x and y for this noise map.
        /// </summary>
        /// <param name="x">The x key of the value you want to get or set.</param>
        /// <param name="y">The y key of the value you want to get or set.</param>
        public float this[int x, int y] {
            get { return _values[x, y]; }
            set {
                var oldValue = _values[x, y];
                _values[x, y] = value;
                onValueUpdated?.Invoke(x,y,oldValue,value);
            }
        }

        /// <summary>
        /// This property is used to get or set the value at the given key for this noise map.
        /// </summary>
        /// <param name="key">The x and y key of the value you want to get or set.</param>
        public float this[Vector2Int key] {
            get { return _values[key.x, key.y];}
            set { _values[key.x, key.y] = value; }
        }

        public int GetBorderCulledSize(int borderCulling) {
            return Size - (borderCulling * 2);
        }

        public int GetBorderCulledValuesCount(int borderCulling) {
            return GetBorderCulledSize(borderCulling) * GetBorderCulledSize(borderCulling);
        }
        
        public Vector2 GeneratedMinMax { get; }

        #endregion

        
        #region Instance Variables
        
        /// <summary>
        /// This array contains the noise map values.
        /// </summary>
        private readonly float[,] _values;

        public delegate void ValueUpdatedDelegate(int x, int y, float oldValue, float newValue);
        public event ValueUpdatedDelegate onValueUpdated;
        
        #endregion

        
        #region Constructor
        
        /// <summary>
        /// This is used to create a new noise map container.  To create a new noise map please use
        /// the <see cref="NoiseGenerator"/>.
        /// </summary>
        /// <param name="size">This size of the noise map.  This is both the width and the height.</param>
        /// <param name="position">The position or offset of the noise.</param>
        public NoiseMap(int size, Vector2 position, Vector2? minMax = null) {
            minMax??=Vector2.up;
            GeneratedMinMax = minMax.Value;
            Size = size;
            Position = position;
            HalfSize = size / 2f;
            NumberOfValues = size * size;
            _values = new float[size, size];
        }
        
        #endregion


        #region Methods

        /// <summary>
        /// This method is used to iterate over the noise map keys.  This should
        /// be used in a foreach loop. 
        /// </summary>
        /// <returns>xy coordinates within this noise map. </returns>
        public IEnumerable<Vector2Int> IterateKeys(int borderCulling = 0) {
            for(var y=borderCulling;y<Size-borderCulling;y++) for(var x = borderCulling; x < Size-borderCulling; x++) {
                yield return new Vector2Int(x, y);
            }
        }

        public bool ContainsKey(Vector2Int key) {
            return key.x > -1 && key.x < Size && key.y > -1 && key.y < Size;
        }

        public bool ClampReduce(Vector2Int key, float amount) {
            if(!ContainsKey(key)) return false;
            this[key] = Mathf.Clamp(this[key] - amount, -1, 1);
            return true;
        }

        public bool ClampGain(Vector2Int key, float amount) {
            if(!ContainsKey(key)) return false;
            this[key] = Mathf.Clamp(this[key] + amount, -1, 1);
            return true;
        }
        
        #endregion

        
        #region Operators
        
        /// <summary>
        /// This operator does returns a new map with the edited values.
        /// </summary>
        /// <param name="left">The NoiseMap that you want to preform the operation on.</param>
        /// <param name="right">The multiply value.</param>
        /// <returns>The modified original NoiseMap.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static NoiseMap operator *(NoiseMap left, float right) {
            if(left == null) throw new ArgumentNullException(nameof(left), "You can't multiply a null NoiseMap.");
            var newMap = new NoiseMap(left.Size, left.Position);
            foreach(var key in left.IterateKeys()) {
                newMap[key] = left[key] * right;
            }
            return newMap;
        }
        
        /// <summary>
        /// This operator does returns a new map with the edited values.
        /// </summary>
        /// <param name="left">The NoiseMap that you want to preform the operation on.</param>
        /// <param name="right">The divisor value. </param>
        /// <returns>The modified original NoiseMap.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        /// <exception cref="DivideByZeroException"></exception>
        public static NoiseMap operator /(NoiseMap left, float right) {
            if(left == null) throw new ArgumentNullException(nameof(left), "You can't divide a null NoiseMap.");
            if(right == 0) throw new DivideByZeroException("You can't divide a NoiseMap by zero.");
            var newMap = new NoiseMap(left.Size, left.Position);
            foreach(var key in left.IterateKeys()) {
                newMap[key] = left[key] / right;
            }
            return newMap;
        }
        
        /// <summary>
        /// This operator does returns a new map with the edited values.
        /// </summary>
        /// <param name="left">The NoiseMap that you want to preform the operation on.</param>
        /// <param name="right">The addition value.</param>
        /// <returns>The modified original NoiseMap.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static NoiseMap operator +(NoiseMap left, float right) {
            if(left == null) throw new ArgumentNullException(nameof(left), "You can't add to a null NoiseMap.");
            if(right == 0) return left;
            var newMap = new NoiseMap(left.Size, left.Position);
            foreach(var key in left.IterateKeys()) {
                newMap[key] = left[key] + right;
            }
            return newMap;
        }
        
        /// <summary>
        /// This operator does returns a new map with the edited values.
        /// </summary>
        /// <param name="left">The NoiseMap that you want to preform the operation on.</param>
        /// <param name="right">The subtraction value.</param>
        /// <returns>The modified original NoiseMap.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static NoiseMap operator -(NoiseMap left, float right) {
            if(left == null) throw new ArgumentNullException(nameof(left), "You can't subtract from a null NoiseMap.");
            if(right == 0) return left;
            var newMap = new NoiseMap(left.Size, left.Position);
            foreach(var key in left.IterateKeys()) {
                newMap[key] = left[key] - right;
            }
            return newMap;
        }
        
        /// <summary>
        /// This operator does returns a new map with the edited values.
        /// </summary>
        /// <param name="left">The NoiseMap that you want to preform the operation on.</param>
        /// <param name="right">The mod divisor value.</param>
        /// <returns>The modified original NoiseMap.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static NoiseMap operator %(NoiseMap left, float right) {
            if(left == null) throw new ArgumentNullException(nameof(left), "You can't mod a null NoiseMap.");
            if(right == 0) return left;
            var newMap = new NoiseMap(left.Size, left.Position);
            foreach(var key in left.IterateKeys()) {
                newMap[key] = left[key] % right;
            }
            return newMap;
        }
        
        #endregion
    }
}