using Amilious.ProceduralTerrain.Map;
using UnityEngine;

namespace Amilious.ProceduralTerrain.Mesh {
    
    public static class MeshChunkGenerator {

        public static MeshData Generate(NoiseMap noiseMap, float maxHeight, MeshSettings meshSettings, int levelOfDetail) {

            var heightMap = noiseMap * maxHeight;
            var meshSimplifier = (levelOfDetail == 0) ? 1 : levelOfDetail * 2;
            var borderedSize = heightMap.Size;
            var meshSize = borderedSize - 2 * meshSimplifier;
            var meshSizeUnsimplified = borderedSize - 2;

            var topLeft = new Vector2(-1, 1) * ((meshSizeUnsimplified - 1) / 2f);

            var vertsPerLine = (meshSize - 1) / meshSimplifier + 1;
            var meshData = new MeshData(vertsPerLine, meshSettings.UseFlatShading);
            var vertexIndicesMap = new int[borderedSize, borderedSize];
            
            var meshVertexIndex = 0;
            var borderVertexIndex = -1;
            
            for(var y=0; y<borderedSize; y+= meshSimplifier)
            for(var x = 0; x < borderedSize; x += meshSimplifier) {
                var isBorderVertex = y == 0 || y == borderedSize - 1 || x == 0 || x == borderedSize - 1;
                if(isBorderVertex) vertexIndicesMap[x, y] = borderVertexIndex--;
                else vertexIndicesMap[x, y] = meshVertexIndex++;
            }
            
            for(var y=0; y<borderedSize; y+= meshSimplifier)
            for(var x = 0; x < borderedSize; x += meshSimplifier) {
                var vertexIndex = vertexIndicesMap[x, y];
                var percent = new Vector2((x - meshSimplifier) / (float)meshSize,
                    (y - meshSimplifier) / (float)meshSize);
                var height = heightMap[x, y];
                var vertexPosition = new Vector3((topLeft.x + percent.x * meshSizeUnsimplified) * meshSettings.MeshScale,
                    height, (topLeft.y - percent.y * meshSizeUnsimplified) * meshSettings.MeshScale);
                meshData.AddVertex(vertexPosition, percent, vertexIndex);
                if(x >= borderedSize - 1 || y >= borderedSize - 1) continue;
                var a = vertexIndicesMap [x, y];
                var b = vertexIndicesMap [x + meshSimplifier, y];
                var c = vertexIndicesMap [x, y + meshSimplifier];
                var d = vertexIndicesMap [x + meshSimplifier, y + meshSimplifier];
                meshData.AddTriangle (a,d,c);
                meshData.AddTriangle (d,a,b);
            }
            
            meshData.ProcessMesh();
            return meshData;

        }
        
    }

}