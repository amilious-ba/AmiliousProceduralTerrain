namespace Amilious.ProceduralTerrain.Mesh {
    public class MapMesh {
        
    }
}