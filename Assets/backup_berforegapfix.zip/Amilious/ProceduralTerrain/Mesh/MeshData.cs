using UnityEngine;

namespace Amilious.ProceduralTerrain.Mesh {
    public class MeshData {
        
        private Vector3[] _vertices;
        private readonly int[] _triangles;
        private Vector2[] _uvs;
        private Vector3[] _bakedNormals;

        private readonly Vector3[] _borderVertices;
        private readonly int[] _borderTriangles;

        private int _triangleIndex;
        private int _borderTriangleIndex;

        private readonly bool _useFlatShading;

        public MeshData(int verticesPerLine, bool useFlatShading) {
            this._useFlatShading = useFlatShading;
            var sqrVertsPerLine = verticesPerLine * verticesPerLine;
            _vertices = new Vector3[sqrVertsPerLine];
            _uvs = new Vector2[sqrVertsPerLine];
            _triangles = new int[(verticesPerLine - 1) * (verticesPerLine - 1) * 6];
            _borderVertices = new Vector3[verticesPerLine * 4 + 4];
            _borderTriangles = new int[24 * verticesPerLine];
        }

        public void AddVertex(Vector3 vertexPosition, Vector2 uv, int vertexIndex) {
            if(vertexIndex < 0) _borderVertices[-vertexIndex - 1] = vertexPosition;
            else {
                _vertices[vertexIndex] = vertexPosition;
                _uvs[vertexIndex] = uv;
            }
        }

        public void AddTriangle(int a, int b, int c) {
            if(a < 0 || b < 0 || c < 0) {
                _borderTriangles[_borderTriangleIndex++] = a;
                _borderTriangles[_borderTriangleIndex++] = b;
                _borderTriangles[_borderTriangleIndex++] = c;
            }else {
                _triangles[_triangleIndex++] = a;
                _triangles[_triangleIndex++] = b;
                _triangles[_triangleIndex++] = c;
            }
        }

        public void ProcessMesh() {
            if(_useFlatShading) FlatShading();
            else BakeNormals();
        }

        public UnityEngine.Mesh CreateMesh() {
            var mesh = new UnityEngine.Mesh { vertices = _vertices, triangles = _triangles, uv = _uvs };
            if(_useFlatShading) mesh.RecalculateNormals();
            else mesh.normals = _bakedNormals;
            return mesh;
        }

        private Vector3[] CalculateNormals() {
            
            var vertexNormals = new Vector3[_vertices.Length];
            
            var triangleCount = _triangles.Length / 3;
            for(var i = 0; i < triangleCount; i++) {
                var normalTriangleIndex = i * 3;
                var vertexIndexA = _triangles[normalTriangleIndex++];
                var vertexIndexB = _triangles[normalTriangleIndex++];
                var vertexIndexC = _triangles[normalTriangleIndex];
                var triangleNormal = SurfaceNormalFromIndices(vertexIndexA, vertexIndexB, vertexIndexC);
                vertexNormals[vertexIndexA] += triangleNormal;
                vertexNormals[vertexIndexB] += triangleNormal;
                vertexNormals[vertexIndexC] += triangleNormal;
            }

            var borderTriangleCount = _borderTriangles.Length / 3;
            for(var i = 0; i < borderTriangleCount; i++) {
                var normalTriangleIndex = i * 3;
                var vertexIndexA = _borderTriangles[normalTriangleIndex++];
                var vertexIndexB = _borderTriangles[normalTriangleIndex++];
                var vertexIndexC = _borderTriangles[normalTriangleIndex];
                var triangleNormal = SurfaceNormalFromIndices(vertexIndexA, vertexIndexB, vertexIndexC);
                //add normals if not border
                if(vertexIndexA >= 0) vertexNormals[vertexIndexA] += triangleNormal;
                if(vertexIndexB >= 0) vertexNormals[vertexIndexB] += triangleNormal;
                if(vertexIndexC >= 0) vertexNormals[vertexIndexC] += triangleNormal;
            }

            for(var i = 0; i < vertexNormals.Length; i++) vertexNormals[i].Normalize();
            return vertexNormals;

        }

        private Vector3 SurfaceNormalFromIndices(int indexA, int indexB, int indexC) {
            var pointA = (indexA < 0)?_borderVertices[-indexA-1] : _vertices [indexA];
            var pointB = (indexB < 0)?_borderVertices[-indexB-1] : _vertices [indexB];
            var pointC = (indexC < 0)?_borderVertices[-indexC-1] : _vertices [indexC];
            return Vector3.Cross (pointB - pointA, pointC - pointA).normalized;
        }

        private void BakeNormals() {
            _bakedNormals = CalculateNormals();
        }

        private void FlatShading() {
            var flatShadedVertices = new Vector3[_triangles.Length];
            var flatShadedUvs = new Vector2[_triangles.Length];
            for(var i = 0; i < _triangles.Length; i++) {
                flatShadedVertices[i] = _vertices[_triangles[i]];
                flatShadedUvs[i] = _uvs[_triangles[i]];
                _triangles[i] = i;
            }
            _vertices = flatShadedVertices;
            _uvs = flatShadedUvs;
        }

    }
}