using System;
using System.Collections.Concurrent;
using System.Linq;
using Amilious.ProceduralTerrain.Erosion;
using Amilious.ProceduralTerrain.Noise;
using Sirenix.OdinInspector;
using Sirenix.Serialization;
using Sirenix.Utilities.Editor;
using UnityEngine;
using UnityEngine.UI;

namespace Amilious.ProceduralTerrain.Biomes {
    
    [CreateAssetMenu(menuName = "Amilious/Procedural Terrain/Biome Settings", order = 1), HideMonoScript]
    public class BiomeSettings : SerializedScriptableObject, ScatteredBiomeBlender.IBiomeEvaluator {

        private const string TG = "tab group";
        private const string TAB_A = "Settigns";
        private const string TAB_B = "Biomes";
        private const string TAB_C = "Biome Mapping";

        [SerializeField,TabGroup(TG, TAB_A)] private NoiseSettings baseMapSettings;
        [SerializeField,TabGroup(TG, TAB_A)] private NoiseSettings heatMapSettings;
        [SerializeField,TabGroup(TG, TAB_A)] private NoiseSettings moistureMapSettings;
        [SerializeField,TabGroup(TG, TAB_A), Range(-1,1)] private float oceanHeight = 0;
        [SerializeField,TabGroup(TG, TAB_A)] private float blendFrequency;
        [SerializeField,TabGroup(TG, TAB_A)] private float blendRadiusPadding;
        [TabGroup(TG, TAB_B)]
        [SerializeField][ListDrawerSettings(CustomAddFunction = nameof(AddNewBiomeInfo), 
            Expanded = true, DraggableItems = false)] 
        private BiomeInfo[] biomeInfo;
        [TabGroup(TG, TAB_C)]
        [OdinSerialize][TableMatrix(VerticalTitle ="Heat", HorizontalTitle = "Moisture", 
            DrawElementMethod = nameof(GetBiomeDropdown))]
        private int[,] biomeTable;
        [SerializeField, TabGroup(TG, TAB_C), Range(-1,1)]
        private float testHeat;
        [SerializeField, TabGroup(TG, TAB_C), Range(-1,1)]
        private float testMoisture;

        [TabGroup(TG, TAB_C), SerializeField, DisplayAsString, HideLabel, GUIColor(0f,1f,0f)]
        private string testResult = "press test to get the biome for the given levels.";
        
        
        public int GetBiomeDropdown(Rect rect, int value) {
            var values = biomeInfo.Select(x => x.biomeId).ToList();
            var names = biomeInfo.Select(x => x.name).ToList();
            values.Add(0); names.Add("not set");
            return SirenixEditorFields.Dropdown(rect, "", value, values.ToArray(), names.ToArray());
        }
        
        private BiomeInfo AddNewBiomeInfo() {
            Debug.Log("reached");
            var id = 0;
            while(true) {
                id = Guid.NewGuid().GetHashCode();
                if(biomeInfo.All(info => info.biomeId != id)&&id!=0) break;
            }
            return new BiomeInfo { biomeId = id };
        }
        
        private ConcurrentDictionary<int, BiomeInfo> _biomeLookup = new ConcurrentDictionary<int, BiomeInfo>();
        private bool _builtLookup;

        private void Awake() {
            BuildLookup();
        }

        private void OnValidate() {
            TextLookUp();
        }

        private void BuildLookup() {
            if(Application.isPlaying&&_builtLookup) return;
            foreach(var info in biomeInfo)
                _biomeLookup.TryAdd(info.biomeId, info);
            _builtLookup = true;
        }

        public void TextLookUp() {
            var test = GetBiomeInfo(testHeat, testMoisture);
            testResult = $"{test.biomeId}: {test.name}";
        }
        
        public BiomeInfo GetBiomeInfo(int biomeId) {
            BuildLookup();
            return _biomeLookup.TryGetValue(biomeId, out var value) ? value : new 
                BiomeInfo { validBiome = false, biomeId = 0, name = "Invalid", biomeMapColor = Color.magenta};
        }

        public BiomeInfo GetBiomeInfo(float heat, float moisture) => GetBiomeInfo(GetBiomeId(heat, moisture));

        public int GetBiomeId(float heat, float moisture) {
            //convert the -1 to 1 value into an integer value 0 to the array length minus one.
            var x = (int)((moisture+1)*(biomeTable.GetUpperBound(0)+1)*.5f-.0001f);
            var y = (int)((heat+1)*(biomeTable.GetUpperBound(1)+1)*.5f-.0001f);
            return biomeTable[x, y];
        }


        /*public BiomeMap GenerateBiomeMap(int size, int hashedSeed, Vector2? position = null) {
            var heatMap = heatMapSettings.Generate(size, hashedSeed, position);
            var moistureMap = moistureMapSettings.Generate(size, hashedSeed, position);
            var continentOceanMap = continentOceanMapSettings.Generate(size, hashedSeed, position);
            //create the biome map
            var biomeMap = new BiomeMap(hashedSeed, heatMap, moistureMap, continentOceanMap);
            var biomeBlender= new ScatteredBiomeBlender(biomeBlendFrequency,biomeBlendRadiusPadding)
        }*/

        /// <summary>
        /// This method is called by the biome blender.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="z"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public int GetBiomeAt(float x, float z) {
            return 0;
        }
    }
    
    [Serializable]
    public class BiomeInfo {
        
        [HideInInspector]
        public bool validBiome;

        [TableColumnWidth(100, Resizable = false)]
        [HorizontalGroup("Biome")]
        public string name;
        [HorizontalGroup("Biome", Width = 75)]
        [DisplayAsString, HideLabel]
        public int biomeId;
        public Color biomeMapColor;
        public NoiseSettings noiseSettings;
        public MapModifier[] mapModifiers;

    }
}