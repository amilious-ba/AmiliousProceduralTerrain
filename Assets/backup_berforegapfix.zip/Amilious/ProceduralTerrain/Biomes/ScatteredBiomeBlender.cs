using System.Collections.Generic;
using UnityEngine;

//https://github.com/KdotJPG/Scattered-Biome-Blender
//https://noiseposti.ng/posts/2021-03-13-Fast-Biome-Blending-Without-Squareness.html

namespace Amilious.ProceduralTerrain.Biomes {
    
    public class ScatteredBiomeBlender {

        private readonly int chunkColumnCount;
        private readonly int blendRadiusBoundArrayCenter;
        private readonly float chunkWidthMinusOne;
        private readonly float blendRadius, blendRadiusSq;
        private readonly float[] blendRadiusBound;
        private readonly ChunkPointGatherer<LinkedBiomeWeightMap> gatherer;
        
        // chunkWidth should be a power of two.
        public ScatteredBiomeBlender(float samplingFrequency, float blendRadiusPadding, int chunkWidth) {
            this.chunkWidthMinusOne = chunkWidth - 1;
            this.chunkColumnCount = chunkWidth * chunkWidth;
            this.blendRadius = blendRadiusPadding + getInternalMinBlendRadiusForFrequency(samplingFrequency);
            this.blendRadiusSq = blendRadius * blendRadius;
            this.gatherer = new ChunkPointGatherer<LinkedBiomeWeightMap>(samplingFrequency, blendRadius, chunkWidth);
            
            blendRadiusBoundArrayCenter = (int)Mathf.Ceil(blendRadius) - 1;
            blendRadiusBound = new float[blendRadiusBoundArrayCenter * 2 + 1];
            for (int i = 0; i < blendRadiusBound.Length; i++) {
                int dx = i - blendRadiusBoundArrayCenter;
                int maxDxBeforeTruncate = Mathf.Abs(dx) + 1;
                blendRadiusBound[i] = Mathf.Sqrt(blendRadiusSq - maxDxBeforeTruncate);
            }
            
        }
        
        public LinkedBiomeWeightMap GetBlendForChunk(long seed, int chunkBaseWorldX, int chunkBaseWorldZ, IBiomeEvaluator evaluator) {
            
            // Get the list of data points in range.
            var points = gatherer.getPointsFromChunkBase(seed, chunkBaseWorldX, chunkBaseWorldZ);
            
            // Evaluate and aggregate all biomes to be blended in this chunk.
            LinkedBiomeWeightMap linkedBiomeMapStartEntry = null;
            foreach(var point in points) {
                
                // Get the biome for this data point from the callback.
                var biome = evaluator.GetBiomeAt(point.getX(), point.getZ());
                
                // Find or create the chunk biome blend weight layer entry for this biome.
                var entry = linkedBiomeMapStartEntry;
                while (entry != null) {
                    if (entry.GetBiome() == biome) break;
                    entry = entry.GetNext();
                }
                if (entry == null) {
                    entry = linkedBiomeMapStartEntry =
                        new LinkedBiomeWeightMap(biome, linkedBiomeMapStartEntry);
                }
                
                point.setTag(entry);
            }
            
            // If there is only one biome in range here, we can skip the actual blending step.
            if (linkedBiomeMapStartEntry != null && linkedBiomeMapStartEntry.GetNext() == null) {
                /*float[] weights = new float[chunkColumnCount];
                linkedBiomeMapStartEntry.setWeights(weights);
                for (int i = 0; i < chunkColumnCount; i++) {
                    weights[i] = 1.0;
                }*/
                return linkedBiomeMapStartEntry;
            }
            
            for (var entry = linkedBiomeMapStartEntry; entry != null; entry = entry.GetNext()) {
                entry.SetWeights(new float[chunkColumnCount]);
            }
            
            float z = chunkBaseWorldZ, x = chunkBaseWorldX;
            var xStart = x;
            var xEnd = xStart + chunkWidthMinusOne;
            for (var i = 0; i < chunkColumnCount; i++) {
                
                // Consider each data point to see if it's inside the radius for this column.
                var columnTotalWeight = 0.0f;
                foreach(var point in points) {
                    var dx = x - point.getX();
                    var dz = z - point.getZ();
                    
                    var distSq = dx * dx + dz * dz;
                    
                    // If it's inside the radius...
                    if(!(distSq < blendRadiusSq)) continue;
                    // Relative weight = [r^2 - (x^2 + z^2)]^2
                    var weight = blendRadiusSq - distSq;
                    weight *= weight;
                        
                    point.getTag().GetWeights()[i] += weight;
                    columnTotalWeight += weight;
                }
                
                // Normalize so all weights in a column add up to 1.
                var inverseTotalWeight = 1.0f / columnTotalWeight;
                for (var entry = linkedBiomeMapStartEntry; entry != null; entry = entry.GetNext()) {
                    entry.GetWeights()[i] *= inverseTotalWeight;
                }
                
                // A float can fully represent an int, so no precision loss to worry about here.
                if (x == xEnd) {
                    x = xStart;
                    z++;
                } else x++;
            }
            
            return linkedBiomeMapStartEntry;
        }
        
        public static float getInternalMinBlendRadiusForFrequency(float samplingFrequency) {
            return UnfilteredPointGatherer.MAX_GRIDSCALE_DISTANCE_TO_CLOSEST_POINT / samplingFrequency;
        }
        
        public float getInternalBlendRadius() {
            return blendRadius;
        }
        
        public interface IBiomeEvaluator {
            int GetBiomeAt(float x, float z);
        }
        
        private class BiomeEvaluation {
            int biome;
            float tempDzSquared;
            public BiomeEvaluation(int biome) {
                this.biome = biome;
            }
        }
        
    }
}