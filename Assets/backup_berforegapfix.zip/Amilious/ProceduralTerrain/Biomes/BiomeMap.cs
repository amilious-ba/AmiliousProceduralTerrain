using Amilious.ProceduralTerrain.Map;
using UnityEngine;

namespace Amilious.ProceduralTerrain.Biomes {
    public class BiomeMap {

        public BiomeMap(int size, Vector2 position) {
            
        }
        
    }
}