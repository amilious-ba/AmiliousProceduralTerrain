using System;
using System.Collections.Generic;
using UnityEngine;

namespace Amilious.ProceduralTerrain.Biomes {
    
    public class ChunkPointGatherer<T> {

        private static readonly float CHUNK_RADIUS_RATIO = Mathf.Sqrt(1.0f / 2.0f);

        private int halfChunkWidth;
        private float maxPointContributionRadius;
        private float maxPointContributionRadiusSq;
        private float radiusPlusHalfChunkWidth;
        UnfilteredPointGatherer unfilteredPointGatherer;
    
        public ChunkPointGatherer(float frequency, float maxPointContributionRadius, int chunkWidth) {
            this.halfChunkWidth = chunkWidth / 2;
            this.maxPointContributionRadius = maxPointContributionRadius;
            this.maxPointContributionRadiusSq = maxPointContributionRadius * maxPointContributionRadius;
            this.radiusPlusHalfChunkWidth = maxPointContributionRadius + halfChunkWidth;
            unfilteredPointGatherer = new UnfilteredPointGatherer(frequency,
                    maxPointContributionRadius + chunkWidth * CHUNK_RADIUS_RATIO);
        }
        
        public List<GatheredPoint<T>> getPointsFromChunkBase(long seed, int chunkBaseWorldX, int chunkBaseWorldZ) {
            // Technically, the true minimum is between coordinates. But tests showed it was more efficient to add before converting to doubles.
            return getPointsFromChunkCenter(seed, chunkBaseWorldX + halfChunkWidth, chunkBaseWorldZ + halfChunkWidth);
        }
        
        public List<GatheredPoint<T>> getPointsFromChunkCenter(long seed, int chunkCenterWorldX, int chunkCenterWorldZ) {
            List<GatheredPoint<T>> worldPoints =
                    unfilteredPointGatherer.getPoints<T>(seed, chunkCenterWorldX, chunkCenterWorldZ);
            for (int i = 0; i < worldPoints.Count; i++) {
                GatheredPoint<T> point = worldPoints[i];
                
                // Check if point contribution radius lies outside any coordinate in the chunk
                float axisCheckValueX = Mathf.Abs(point.getX() - chunkCenterWorldX) - halfChunkWidth;
                float axisCheckValueZ = Mathf.Abs(point.getZ() - chunkCenterWorldZ) - halfChunkWidth;
                if (axisCheckValueX >= maxPointContributionRadius || axisCheckValueZ >= maxPointContributionRadius
                        || (axisCheckValueX > 0 && axisCheckValueZ > 0
                            && axisCheckValueX*axisCheckValueX + axisCheckValueZ*axisCheckValueZ >= maxPointContributionRadiusSq)) {
                    
                    // If so, remove it.
                    // Copy the last value to this value, and remove the last,
                    // to avoid shifting because order doesn't matter.
                    int lastIndex = worldPoints.Count - 1;
                    worldPoints[i] = worldPoints[lastIndex];
                    worldPoints.RemoveAt(lastIndex);
                    //worldPoints.set(i, worldPoints.get(lastIndex));
                    //worldPoints.remove(lastIndex);
                    i--;
                }
            }
            
            return worldPoints;
        }

    }
    
}