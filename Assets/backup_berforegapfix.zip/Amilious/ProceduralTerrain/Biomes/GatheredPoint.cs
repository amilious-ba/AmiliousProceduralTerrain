namespace Amilious.ProceduralTerrain.Biomes {
    public class GatheredPoint<T> {

        private float x, z;
        private int hash;
        private T tag;

        public GatheredPoint(float x, float z, int hash) {
            this.x = x;
            this.z = z;
            this.hash = hash;
        }
        
        public float getX() {
            return x;
        }
    
        public float getZ() {
            return z;
        }
    
        public float getHash() {
            return hash;
        }
    
        public T getTag() {
            return tag;
        }
    
        public void setTag(T tag) {
            this.tag = tag;
        }
        
    }
}