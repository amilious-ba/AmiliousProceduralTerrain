namespace Amilious.ProceduralTerrain.Biomes {
    
    
    public class LinkedBiomeWeightMap {
        
        private int biome;
        private float[] weights;
        private LinkedBiomeWeightMap next;

        public LinkedBiomeWeightMap(int biome, LinkedBiomeWeightMap next) {
            this.biome = biome;
            this.next = next;
        }

        public LinkedBiomeWeightMap(int biome, int chunkColumnCount, LinkedBiomeWeightMap next) {
            this.biome = biome;
            this.weights = new float[chunkColumnCount];
            this.next = next;
        }
        

        public int GetBiome() {
            return biome;
        }

        public float[] GetWeights() {
            return weights;
        }

        public void SetWeights(float[] weights) {
            this.weights = weights;
        }

        public LinkedBiomeWeightMap GetNext() => next;

    }
}