using System;
using System.Diagnostics;
using Amilious.ProceduralTerrain.Map;
using Amilious.ProceduralTerrain.Textures;
using Amilious.Random;
using Sirenix.OdinInspector;
#if UNITY_EDITOR
using UnityEngine;
#endif

namespace Amilious.ProceduralTerrain.Noise {

    [CreateAssetMenu(menuName = "Amilious/Procedural Terrain/Noise Settings", order = -1), HideMonoScript]
    public class NoiseSettings : UpdateableData {

        public const float AMPLITUDE_MINIMUM = 0.0001f;
        public const float AMPLITUDE_MAXIMUM = 1f;
        public const string PREVIEW = "Preview";
        public const string TAB_GROUP = "Settings";
        public const string TAB_A = "General";
        public const string TAB_B = "Fractal";
        public const string TAB_C = "Cellular";
        public const string TAB_D = "Domain Warp";
        public const string TAB_E = "Domain Warp Fractal";

        private FastNoiseLite _noise;

        /// <summary>
        /// Preview Inspector
        /// </summary>
        [Tooltip("This is the seed that is used for random generation.")]
        [BoxGroup(PREVIEW), OnInspectorGUI("DrawPreview", append: false)]
        [BoxGroup(PREVIEW), SerializeField]
        private string seed = "seedless";
        [Tooltip("This is the size of the generated noise map used for the preview.")]
        [BoxGroup(PREVIEW), SerializeField]
        private int size = 100;
        [Tooltip("This is the pixel multiplier used for the preview.")] [BoxGroup(PREVIEW), SerializeField]
        private int pixelMultiplier = 2;
        [Tooltip("This is the offset value used for the preview.")] [BoxGroup(PREVIEW), SerializeField]
        private Vector2 offset;
        [BoxGroup(PREVIEW), SerializeField] private PreviewType previewType = PreviewType.NoiseMap;
        [BoxGroup(PREVIEW), SerializeField, ShowIf("previewType", PreviewType.ColorMap)]
        private ColorMap colorMap;
        [BoxGroup(PREVIEW), SerializeField, ShowIf("previewType", PreviewType.CrossSection)]
        [PropertyRange(1,nameof(size))]
        private int crossSectionDepth = 0;

        [TabGroup(TAB_GROUP, TAB_A), SerializeField]
        private FastNoiseLite.NoiseType noiseType = FastNoiseLite.NoiseType.OpenSimplex2;
        [TabGroup(TAB_GROUP,TAB_A), SerializeField]
        private float frequency = 0.07f;
        [TabGroup(TAB_GROUP, TAB_A), SerializeField]
        private bool useNoiseCurve = true;
        [TabGroup(TAB_GROUP,TAB_A),SerializeField, ShowIf(nameof(useNoiseCurve))] 
        private AnimationCurve noiseCurve = AnimationCurve.Linear(-1f, -1f, 1f, 1f);

        [TabGroup(TAB_GROUP, TAB_B), SerializeField]
        private FastNoiseLite.FractalType fractalType = FastNoiseLite.FractalType.FBm;
        [TabGroup(TAB_GROUP, TAB_B), SerializeField]
        private int fractalOctaves = 5;
        [TabGroup(TAB_GROUP, TAB_B), SerializeField]
        private float fractalLacunarity = 2;
        [TabGroup(TAB_GROUP, TAB_B), SerializeField]
        private float fractalGain = .5f;
        [TabGroup(TAB_GROUP, TAB_B), SerializeField]
        private float waitedStrength = 1;
        [TabGroup(TAB_GROUP, TAB_B), SerializeField]
        private float pingPongStrength = 2;

        [TabGroup(TAB_GROUP, TAB_C), SerializeField]
        private FastNoiseLite.CellularDistanceFunction distanceFunction = 
            FastNoiseLite.CellularDistanceFunction.Euclidean;
        [TabGroup(TAB_GROUP, TAB_C), SerializeField]
        private FastNoiseLite.CellularReturnType returnType =
            FastNoiseLite.CellularReturnType.Distance;
        [TabGroup(TAB_GROUP, TAB_C), SerializeField]
        private float cellularJitter = 1f;


        public ColorMap PreviewColors { get => colorMap; }
        
        private void Awake() {
            SetUpNoise();
        }

#if UNITY_EDITOR

        protected override void OnValidate() {
            crossSectionDepth = Mathf.Min(crossSectionDepth, size);
            base.OnValidate();
            SetUpNoise();
        }

        private Stopwatch _stopwatch = new Stopwatch();
        private GUIStyle _timerGUI;
        private void DrawPreview() {
            if(_timerGUI == null) {
                _timerGUI = new GUIStyle();
                _timerGUI.normal.textColor = Color.red;
            }
            _stopwatch.Reset();
            _stopwatch.Start();
            var noiseMap = Generate(size, SeedGenerator.GetSeedInt(seed), offset);
            _stopwatch.Stop();
            var time1 = $"  Noise Map: min {_stopwatch.Elapsed.Minutes} sec {_stopwatch.Elapsed.Seconds} ms {_stopwatch.Elapsed.Milliseconds}";
            _stopwatch.Reset();
            _stopwatch.Start();
            var noiseTexture = previewType switch {
                PreviewType.NoiseMap => noiseMap.GenerateTexture(pixelMultiplier: pixelMultiplier),
                PreviewType.ColorMap => noiseMap.GenerateTexture(colorMap, pixelMultiplier),
                PreviewType.CrossSection => noiseMap.GenerateCrossSectionTexture(Color.white, 
                    Color.black,crossSectionDepth-1,pixelMultiplier),
                _ => throw new ArgumentOutOfRangeException()
            };
            _stopwatch.Stop();
            var time2 = $"  Texture: min {_stopwatch.Elapsed.Minutes} sec {_stopwatch.Elapsed.Seconds} ms {_stopwatch.Elapsed.Milliseconds}";
            GUILayout.BeginVertical(GUI.skin.box);
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.Label($"{size}X{size} Noise Sample x {pixelMultiplier}");
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.Label(noiseTexture);
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            GUILayout.Label(time1,_timerGUI);
            GUILayout.Label(time2,_timerGUI);
            GUILayout.EndVertical();
        }
        #endif

        private void SetUpNoise() {
            //create noise generator
            _noise ??= new FastNoiseLite();
            //apply settings
            _noise.SetNoiseType(noiseType);
            _noise.SetFrequency(frequency);
            _noise.SetFractalType(fractalType);
            _noise.SetFractalOctaves(fractalOctaves);
            _noise.SetFractalLacunarity(fractalLacunarity);
            _noise.SetFractalGain(fractalGain);
            _noise.SetFractalWeightedStrength(waitedStrength);
            _noise.SetFractalPingPongStrength(pingPongStrength);
            _noise.SetCellularDistanceFunction(distanceFunction);
            _noise.SetCellularReturnType(returnType);
            _noise.SetCellularJitter(cellularJitter);
            
            
        }

        //TODO: cache the seed value as an int
        public NoiseMap Generate(int size, int hashedSeed, Vector2? position = null) {

            //get things set up
            position ??= Vector2.zero;
            var noiseMap = new NoiseMap(size, position.Value, new Vector2(-1,1));
            _noise.SetSeed(hashedSeed);
            var centerX = noiseMap.Position.x - noiseMap.HalfSize;
            var centerY = -noiseMap.Position.y - noiseMap.HalfSize;
            var curve = new AnimationCurve(noiseCurve.keys);

            //generate noise
            foreach(var key in noiseMap.IterateKeys()) {
                var value = _noise.GetNoise(key.x + centerX, key.y + centerY);
                if(useNoiseCurve) value = curve.Evaluate(value);
                noiseMap[key] = value;
            }

            return noiseMap;

        }

        public float NoiseAtPoint(float x, float z, int hashedSeed) {
            _noise.SetSeed(hashedSeed);
            var curve = new AnimationCurve(noiseCurve.keys);
            var value = _noise.GetNoise(x, z);
            if(useNoiseCurve) value = curve.Evaluate(value);
            return value;
        }

    }
}