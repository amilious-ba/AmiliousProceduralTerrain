namespace Amilious.ProceduralTerrain.Noise {
    public enum PreviewType {
        NoiseMap, ColorMap, CrossSection
    }
}