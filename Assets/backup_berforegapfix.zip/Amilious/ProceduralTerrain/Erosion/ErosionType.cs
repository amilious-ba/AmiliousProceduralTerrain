namespace Amilious.ProceduralTerrain.Erosion {
    public enum ErosionType {
        Rain, Tidal, Thermal, River, Wind
    }
}